angular.module('ineeditApp', ['ionic','ineeditControllers','ineeditFilters'])

.config(['$stateProvider','$urlRouterProvider', 
  function($stateProvider, $urlRouterProvider) {

	  $stateProvider
	  	.state('Home', {
			url: '/',
			controller: 'HomeCtrl', 
			templateUrl: 'partials/home.html'
		})
	  	.state('Services', {
			url: '/services',
			controller: 'ServiceListCtrl',
			templateUrl: 'partials/service-list.html'
		})
	  	.state('Service', {
			url: '/service/:serviceId', 
			controller: 'ServiceDetailCtrl', 
			templateUrl: 'partials/service-detail.html'
		})
	  	.state('Place', {
			url: '/place/:placeId', 
			controller: 'PlaceDetailCtrl', 
			templateUrl: 'partials/place-detail.html'
		})

    .state('login', {
    url: '/login',
    
  templateUrl: 'partials/login.html',
    controller: 'loginCtrl'
  })
  .state('service_urgent', {
    url: '/service_urgent',
    
  templateUrl: 'partials/service-list-urgent.html',
    controller: 'urgentCtrl'
  })
  

  

	  $urlRouterProvider.otherwise("/");

}])	


.run(function($ionicPlatform,$rootScope,$location, $ionicPopup) {
	
  $rootScope.goHome = function() {
	//$location.path('/services');
  history.go(-1);
  };
	
 

  
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if(window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }

if(window.Connection) {
    
      if(navigator.connection.type == Connection.NONE) {
        $ionicPopup.alert({
          title: 'Pas de connexion Internet',
          content: 'Désolé, aucune connexion Internet n\'a été détectée. reconnecter-vous et réessayez.'
        })
        

        .then(function(result) {

          if (result){
           
 
                
          }
        });
      }
    }

 



});
